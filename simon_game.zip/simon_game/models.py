from peewee import Model, CharField, SqliteDatabase, AutoField

db = SqliteDatabase('database.db')

class User(Model):
    id = AutoField(primary_key=True)
    username = CharField(unique=True)
    email = CharField(unique=True)
    password = CharField()

    class Meta:
        database = db

# Cria as tabelas no banco de dados
db.connect()
db.create_tables([User], safe=True)
