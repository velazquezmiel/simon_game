from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import bcrypt

app = FastAPI()

# Allow CORS for all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for demo purposes
users = {}
scores_db = [
    {"username": "Ale mãe❤", "score": 19},
    {"username": "melmelrs", "score": 17},
    {"username": "teste", "score": 15},
]

class CreateUser(BaseModel):
    username: str
    email: str
    password: str

class ShowUser(BaseModel):
    username: str
    email: str
    password: str

class LoginData(BaseModel):
    email: str
    password: str

class Score(BaseModel):
    username: str
    score: int

@app.post("/register")
async def register(user: CreateUser):
    if user.email in users:
        raise HTTPException(status_code=400, detail="Email already registered")

    # Hash the password
    hashed_password = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt())
    users[user.email] = CreateUser(username=user.username, email=user.email, password=hashed_password.decode('utf-8'))
    return {"success": True, "message": "User registered successfully", "username": user.username}  # Retornar o nome de usuário

@app.post("/login")
async def login(data: LoginData):
    user = users.get(data.email)
    if user and bcrypt.checkpw(data.password.encode('utf-8'), user.password.encode('utf-8')):
        return {
            "success": True,
            "message": "Login successful",
            "username": user.username  # Retornar o nome de usuário
        }
    raise HTTPException(status_code=400, detail="Invalid email or password")

@app.get("/users", response_model=list[ShowUser])
async def get_users():
    # Return a list of registered users
    return [ShowUser(username=user.username, email=user.email, password=user.password) for user in users.values()]

@app.get("/scores/top", response_model=list[Score])
async def get_top_scores():
    top_scores = sorted(scores_db, key=lambda x: x['score'], reverse=True)[:3]
    return top_scores